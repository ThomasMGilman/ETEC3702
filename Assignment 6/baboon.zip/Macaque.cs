﻿using System;

public class Macaque
{
    public static void onRope(){
    }

    public static void offRope(){
    }

}

