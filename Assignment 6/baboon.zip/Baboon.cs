﻿using System;

public class Baboon
{
    static public void onRope(){
    }

    public static void offRope(){
    }

}

