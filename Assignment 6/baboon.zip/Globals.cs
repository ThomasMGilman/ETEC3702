﻿
public class Globals
{
  
}

