﻿using System;

public class Agent
{
    public Agent(){
    }
    public void putPaper(){
    }
    public void putTobacco(){
    }
    public void putMatches(){
    }
    public void waitForSignal(){
    }
}
