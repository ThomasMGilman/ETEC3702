﻿using System;

public class Globals
{
    public Globals()
    {
    }
}

